import { styleText } from "util";
import { Escena } from "./Escena";
import { Final } from "./Final";
import { Personaje } from "./Personaje";
import { keyInSelect } from "readline-sync";

export class Ruta{
    #escenas:Escena[];
    #personajes:Personaje[];
    #finales:Final[];

    constructor(escenas:Escena[],personajes:Personaje[],finales:Final[]){
        this.#escenas = escenas;
        this.#personajes = personajes;
        this.#finales = finales;
    }

    // GETTERS Y SETTERS
    public get escenas(){
        return this.#escenas;
    }
    public set escenas(nuevasEscenas:Escena[]){
        this.#escenas = nuevasEscenas;
    }

    public get personajes(){
        return this.#personajes;
    }
    public set personajes(nuevosPersonajes:Personaje[]){
        this.#personajes = nuevosPersonajes;
    }

    public get finales(){
        return this.#finales;
    }
    public set finales(nuevosFinales:Final[]){
        this.#finales = nuevosFinales;
    }

    // METODOS DE LA CLASE

    public iniciar(){
        let bandera = true;

        while(bandera){
            let escenaIntro = this.#escenas[0];
            escenaIntro.iniciar();

            let decision = escenaIntro.decisiones[0];
            let prota = this.#personajes[0];
            let seleccion = prota.tomarDecision(decision);

            let escenarioSiguiente = this.#escenas[seleccion+1];
            escenarioSiguiente.iniciar();

            let final = this.#finales[seleccion];
            final.mostrar();

            if(final.tipo.includes("Game Over")){
                console.log(styleText('red',"\n Has muerto."));

                let reintentar = keyInSelect(["Reintentar","Terminar ruta"],"Que deseas hacer?",{cancel:false});

                if(reintentar == 0){
                    bandera = true;
                }else{
                    bandera = false;
                }
            }else{
                bandera = false;
            }
            
        }
    }

    public finalizar(){
        console.log("===RUTA FINALIZADA===");
    }
}