import { question } from "readline-sync";
import { Trama } from "./Trama";

console.log("Bienvenido a la novela textual.");
const nombreProtagonista = question("Que nombre quiere darle al protagonista?\n");

const NOVELA = new Trama(nombreProtagonista);
NOVELA.arrancar()