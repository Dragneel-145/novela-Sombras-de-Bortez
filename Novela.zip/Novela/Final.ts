import { styleText } from "util";
import { Escena } from "./Escena";

export class Final{
    #escena:Escena;
    #tipo:string;

    constructor(escena:Escena,tipo:string){
        this.#escena = escena;
        this.#tipo = tipo;
    }

    // GETTERS Y SETTERS
    public get escena(){
        return this.#escena;
    }
    public set escena(nuevaEscena:Escena){
        this.#escena = nuevaEscena;
    }

    public get tipo(){
        return this.#tipo;
    }
    public set tipo(nuevoTipo:string){
        this.#tipo = nuevoTipo;
    }

    // METODOS DE LA CLASE
    public mostrar(){
        console.log("\n================================");
        console.log(this.#tipo);
        console.log("================================");

        this.#escena.iniciar();
    }
}