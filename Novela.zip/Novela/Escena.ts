import { Decision } from "./Decision";
import { Personaje } from "./Personaje";

export class Escena{
    #decisiones:Decision[];
    #personajes:Personaje[];
    #dialogos:string[];

    constructor(decisiones:Decision[],personajes:Personaje[],dialogos:string[]){
        this.#decisiones = decisiones;
        this.#dialogos = dialogos;
        this.#personajes = personajes;
    }

    // GETTERS Y SETTERS
    public get decisiones(){
        return this.#decisiones;
    }
    public set decisiones(nuevasDecisiones:Decision[]){
        this.#decisiones = nuevasDecisiones;
    }

    public get personajes(){
        return this.#personajes;
    }
    public set personajes(nuevosPersonajes:Personaje[]){
        this.#personajes = nuevosPersonajes;
    }

    public get dialogos(){
        return this.#dialogos;
    }
    public set dialogos(nuevosDialogos:string[]){
        this.#dialogos = nuevosDialogos;
    }

    // METODOS DE LA CLASE

    public iniciar(){
        for(const linea of this.#dialogos){
            let partes = linea.split(':')

            let nombrePersonaje = partes[0];
            let mensaje = partes[1];

            let personaje = this.#personajes.find(personaje => personaje.nombre==nombrePersonaje)

            personaje?.dialogar(mensaje);
        }
    }

    public finalizar(){
        console.log("=== FIN DE LA ESCENA ===");
    }
}