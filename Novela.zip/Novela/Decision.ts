import { keyInSelect } from "readline-sync";

export class Decision{
    #opciones:string[];
    #introduccion:string;

    constructor(opciones:string[],introduccion:string){
        this.#opciones = opciones;
        this.#introduccion = introduccion;
    }

    // GETTERS Y SETTERS
    public get opciones(){
        return this.#opciones;
    }
    public set opciones(nuevasOpciones:string[]){
        this.#opciones = nuevasOpciones;
    }
    public get introduccion(){
        return this.#introduccion;
    }
    public set introduccion(nuevaIntroduccion:string){
        this.#introduccion = nuevaIntroduccion;
    }

    // METODOS DE LA CLASE

    public seleccionar(){
        return keyInSelect(this.#opciones,"Tu seleccion: ",{cancel:false})
    }
}