import { styleText } from "util";
import { Decision } from "./Decision";

export class Personaje{
    #nombre:string;
    #colorFondo:string;

    constructor(nombre:string,colorFondo:string){
        this.#nombre = nombre;
        this.#colorFondo = colorFondo;
    }

    // GETTER Y SETTER

    public get nombre(){
        return this.#nombre;
    }
    public set nombre(nuevoNombre:string){
        this.#nombre = nuevoNombre;
    }

    public get colorFondo(){
        return this.#colorFondo;
    }
    public set colorFondo(nuevoColor:string){
        this.#colorFondo = nuevoColor;
    }

    // METODOS DE LA CLASE

    public dialogar(mensaje:string){
        console.log(styleText(this.#colorFondo as any,this.#nombre+" - "+mensaje))
    }

    public tomarDecision(decision:Decision){
        return decision.seleccionar();
    }
}