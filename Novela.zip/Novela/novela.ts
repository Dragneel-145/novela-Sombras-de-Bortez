
import { styleText } from "node:util";
import { question } from "readline-sync";
const rl = require('readline-sync');
export class historia{
    private titulo:string="Sombras de Bortez";
    private personajes=new narrador();
    private escena=new escena();
    introducirhistoria(){
        this.personajes.explicarhistoria();
        this.escena.mostrarescena1();
        this.escena.mostrarescena2();
    }
    DesarrollarHistoria(){
        this.escena.cambiarruta();
    }
    
}

export class escena{
    private nombreEscenaruta1:string[]=["Despertar en Arcadia","Primer dilema"," Entrada al laboratorio",
        "Sala de archivos","Sala de máquinas","Pasillo bloqueado"
    ];
    private nombreEscenarioruta2:string[]=["Callejón oscuro","Criatura aparece","Escape","Pasaje secreto"];
    private nombreEscenarioruta3:string[]=["Puerta blindada con símbolos","Archivo personal"," Túnel de escape","Símbolos trampa"];
    private personajes:personaje[]=[new protagonista(),new narrador(),new personaje()];

   
    mostrarescena1(){
        console.log(this.nombreEscenaruta1[0]);
        this.personajes[2].dialogarConelProta();
       (this.personajes[0] as protagonista).dialogarConelPersonaje();
       this.personajes[2].dialogarConelProta2();
       (this.personajes[1] as narrador).explicarsituacion();
        
    }
    mostrarescena2(){
        console.log(this.nombreEscenaruta1[1]);
        this.personajes[0].darOpciones();
        (this.personajes[0] as protagonista).tomardecision();
    }

    cambiarruta(){
        console.log("Que ruta quieres ir? 1-2-3")
        var decision=rl.questionInt("seleccione cual quieres ir: ")
        do{
        switch(decision){
            case 1:
                console.log(this.nombreEscenaruta1[2]);
                this.mostrarutaA();
                
                break;
            case 2:
                console.log(this.nombreEscenarioruta2[0])
                this.mostrarutB()    
                break;
            case 3:
                console.log(this.nombreEscenarioruta3[0])
                this.mostrarrutC() 
                break;
                default:
        }
        var decs=rl.question("quieres volver empezar presione 1 para volver 2 para terminar")
    }while(decs==1)   
    }
    
    mostrarutaA(){
        (this.personajes[1] as narrador).explicarsituacion2();
        this.personajes[2].dialogarConelProta3();
        console.log("Decisión 1: Sí, entremos de una vez.")
        console.log("Decisión 2: Mejor revisemos el perímetro primero.")
        console.log("Decisión 3: Retrocedamos, quizá haya otra entrada.")
        var deci2=rl.questionInt("que decision eliges?: ")

        switch(deci2){
            case 1:
                console.log(this.nombreEscenaruta1[3]);
                (this.personajes[1] as narrador).explicarsituacion3();
                this.personajes[2].dialogarConelProta4();
                (this.personajes[0] as protagonista).dialogarConelPersonaje3();
                console.log(styleText(["bgGray"],"¿Quién controla realmente tu destino?"))
                break;
            case 2:
                console.log(this.nombreEscenaruta1[4]);
                (this.personajes[1] as narrador).explicarsituacion4();
                this.personajes[2].dialogarConelProta5();
                this.personajes[2].dialogarConelProta16();
                (this.personajes[0] as protagonista).dialogarConelPersonaje4();
                console.log(styleText(["bgWhite"],"Has sobrevivido, pero no conoces toda la verdad."))
                break;
            case 3:
                console.log(this.nombreEscenaruta1[5]);
                (this.personajes[1] as narrador).explicarsituacion5();
                this.personajes[2].dialogarConelProta6();
                this.personajes[2].dialogarConelProta8();
                console.log(styleText(["bgRed"],"Has caído en las sombras de Arcadia."))
                break;
            default:
                break;
        }
    }
    



    mostrarutB(){
        (this.personajes[1] as narrador).explicarsituacion6()
        this.personajes[2].dialogarConelProta7();
        console.log("Decisión 1: Enfrentemos lo que sea.")
        console.log("Decisión 2: Corramos hacia la salida.")
        console.log("Decisión 3: Escondámonos en las sombras.")
        var deci2=rl.questionInt("que decision eliges? 1-2-3: ")

        switch(deci2){
            case 1:
                console.log(this.nombreEscenarioruta2[1]);
                (this.personajes[1] as narrador).explicarsituacion7();
                this.personajes[2].dialogarConelProta8();
                console.log(styleText(["bgRed"],"Fin del juego. El callejón se convierte en tu tumba."))
                break;
            case 2:
                console.log(this.nombreEscenarioruta2[2]);
                (this.personajes[1] as narrador).explicarsituacion8();
                this.personajes[2].dialogarConelProta9();
                this.personajes[2].dialogarConelProta13();
                (this.personajes[0] as protagonista).dialogarConelPersonaje5();
                console.log(styleText(["bgWhite"],"Has sobrevivido, pero el misterio continúa"))
                break;
            case 3:
                console.log(this.nombreEscenarioruta2[3]);
                (this.personajes[1] as narrador).explicarsituacion9();
                this.personajes[2].dialogarConelProta10();
                this.personajes[2].dialogarConelProta15();
                (this.personajes[0] as protagonista).dialogarConelPersonaje6();
                console.log(styleText(["bgGray"],"La verdad te consume. ¿Quién eres realmente?"))
                break;

            default:
                break;
        }
    }
    mostrarrutC(){
        (this.personajes[1] as narrador).explicarsituacion10();
        this.personajes[2].dialogarConelProta11();
        console.log("Decisión 1: Abramos la puerta")
        console.log("Decisión 2: Ignorémosla y sigamos.")
        console.log("Decisión 3: Intentemos descifrar los símbolos.")
        var deci2=rl.questionInt("que decision eliges?: ")

        switch(deci2){
            case 1:
                console.log(this.nombreEscenarioruta3[1]);
                (this.personajes[1] as narrador).explicarsituacion11();
                this.personajes[2].dialogarConelProta12();
                (this.personajes[0] as protagonista).dialogarConelPersonaje3();
                console.log(styleText(["bgGray"],"El misterio apenas comienza."))
                break;
            case 2:
                console.log(this.nombreEscenarioruta3[2]);
                (this.personajes[1] as narrador).explicarsituacion12();
                this.personajes[2].dialogarConelProta13();
                console.log(styleText(["bgWhite"],"Has sobrevivido, pero la verdad quedó sellada."))
                break;
            case 3:
                console.log(this.nombreEscenarioruta3[3]);
                (this.personajes[1] as narrador).explicarsituacion13();
                this.personajes[2].dialogarConelProta8();
                console.log(styleText(["bgGray"],"Has sido víctima de la trampa. Game Over."))
                break;

            default:
                break;
        }
    }
}
export class personaje{
    private nombre:string="Elena bortez";
    
    get nombres(){
        return this.nombre;
    }


    dialogarConelProta(){
    console.log(styleText(["blueBright"],"Tu… ¿estás bien? Te encontré inconsciente entre los restos de la ciudad. No sé cómo sobreviviste."))
   
    }
    dialogarConelProta2(){
     console.log(styleText(["blueBright"],"Arcadia fue destruida por los experimentos de mi padre. Y ahora… algo nos persigue."))
    }
    darOpciones(){
        console.log(styleText(["blueBright"],"Debemos movernos. Hay tres caminos: "))
        console.log(styleText(["blueBright"],"El laboratorio principal, donde quizás encontremos respuestas."))
        console.log(styleText(["blueBright"],"El callejón oscuro, que podría llevarnos a una salida rápida"))
        console.log(styleText(["blueBright"],"esa sala sellada, cubierta de símbolos extraños."))
    }
     dialogarConelProta3(){
     console.log(styleText(["blueBright"]," Prota… ¿seguro que quieres entrar aquí? Algo me dice que no deberíamos."))
    }
    dialogarConelProta4(){
     console.log(styleText(["blueBright"]," ¿Por qué habría algo tuyo aquí…"))
    }
    dialogarConelProta5(){
     console.log(styleText(["blueBright"]," Podemos salir por aquí."))
    }
    dialogarConelProta6(){
     console.log(styleText(["blueBright"]," ¡Prota, cuidado!"))
    }
    dialogarConelProta7(){
     console.log(styleText(["blueBright"]," ¡Algo viene hacia nosotros!"))
    }
    dialogarConelProta8(){
     console.log(styleText(["blueBright"]," ¡Nooo, Prota!"))
    }
    dialogarConelProta9(){
     console.log(styleText(["blueBright"]," Lo conseguimos."))
    }
     dialogarConelProta10(){
     console.log(styleText(["blueBright"]," ¿Qué es este lugar…?"))
    }
    
     dialogarConelProta11(){
     console.log(styleText(["blueBright"]," ¿Qué hacemos, Prota?."))
    }
     dialogarConelProta12(){
     console.log(styleText(["blueBright"]," Entonces… ¿tú también eres parte del experimento?"))
    }
      dialogarConelProta13(){
     console.log(styleText(["blueBright"]," Estamos a salvo"))
    }
    dialogarConelProta14(){
     console.log(styleText(["blueBright"],"¡Prota, nooo!"))
    }
     dialogarConelProta15(){
     console.log(styleText(["blueBright"],"¿Entonces todo esto estaba planeado… incluso tú"))
    }
     dialogarConelProta16(){
     console.log(styleText(["blueBright"],"Lo logramos, Prota. Quizás aún haya esperanza."))
    }
     
    
    
    
   
}

export class protagonista extends personaje{
    private nombreprota:string="tu";
    get nombreprotas(){
        return this.nombreprota;
    }
    dialogarConelPersonaje(){
        console.log(styleText(["cyan"],"No recuerdo nada… solo mi nombre. ¿Qué pasó aquí?"))
    }
    tomardecision(){
        console.log(styleText(["cyan"],"Decidiré… pero sé que cada camino puede cambiar nuestro destino."))
       
    }
    dialogarConelPersonaje2(){
        console.log(styleText(["cyan"],"Prota… ¿seguro que quieres entrar aquí? Algo me dice que no deberíamos."))
    }
    dialogarConelPersonaje3(){
        console.log(styleText(["cyan"],"No soy quien pensaba… ¿qué significa mi existencia?"))
    }
    dialogarConelPersonaje4(){
        console.log(styleText(["cyan"],"Sí… pero el misterio del laboratorio seguirá oculto."))
    }
    dialogarConelPersonaje5(){
        console.log(styleText(["cyan"],"Sí, pero Arcadia aún guarda secretos."))
    }
    dialogarConelPersonaje6(){
        console.log(styleText(["cyan"],"Soy parte de algo más grande… y desconocido"))
    }
    
    dialogarConelPersonaje8(){
        console.log(styleText(["cyan"],"Sí… pero nunca sabremos qué había tras esa puerta"))
    }
    dialogarConelPersonaje9(){
        console.log(styleText(["cyan"],"Prota… ¿seguro que quieres entrar aquí? Algo me dice que no deberíamos."))
    }
   
    dialogarConelPersonaje11(){
        console.log(styleText(["cyan"],"Prota… ¿seguro que quieres entrar aquí? Algo me dice que no deberíamos."))
    }
}

export class narrador extends personaje{
    private nombreNarrador="narrador";

    explicarhistoria(){
    console.log(styleText(["green"],`Año 2147. La ciudad de Arcadia yace en ruinas tras el colapso tecnológico. Entre escombros y laboratorios 
    olvidados, secretos prohibidos esperan ser descubiertos. Tú despiertas sin recuerdos, acompañado por Elena Bortez, 
    hija del hombre que creó esta pesadilla.`))
    }
    explicarsituacion(){
        console.log(styleText(["green"]," El viento arrastra ecos de pasos metálicos. La ciudad parece observarlos"))
    }
    explicarsituacion2(){
        console.log(styleText(["green"],"Las puertas oxidadas se abren con un chirrido. El aire huele a polvo y químicos. "))
    }
    explicarsituacion3(){
         console.log(styleText(["green"],"Montones de carpetas y pantallas apagadas. Un archivo lleva tu nombre"))
    }
    explicarsituacion4(){
        console.log(styleText(["green"]," Motores oxidados y luces parpadeantes. Parece seguro, pero inestable."))
    }
       
    explicarsituacion5(){
        
        console.log(styleText(["green"],"Un ruido fuerte detrás de ti. Algo se acerca."))
    }
    explicarsituacion6(){
        console.log(styleText(["green"],"El callejón está húmedo y silencioso. Un ruido metálico resuena"))
        
    }
     explicarsituacion7(){
          console.log(styleText(["green"],"Una bestia surge y te ataca sin piedad."))
    }
     explicarsituacion8(){
          console.log(styleText(["green"],"Logras salir del callejón y ver la luz del amanecer."))
    }
     explicarsituacion9(){
        console.log(styleText(["green"],"Encuentras un túnel oculto que lleva al laboratorio."))
        
    }
    explicarsituacion10(){
        console.log(styleText(["green"],"Una puerta metálica cubierta de símbolos extraños bloquea el paso."))
        
    }
    explicarsituacion11(){
        console.log(styleText(["green"],"Dentro encuentras documentos con tu nombre."))
        
    }
    explicarsituacion12(){
        console.log(styleText(["green"],"Encuentras un túnel que lleva fuera de Arcadia."))
        
    }
    explicarsituacion13(){
        console.log(styleText(["green"],"Los símbolos brillan y liberan un mecanismo mortal."))
        
    }
}


// el protagonista indica su nombre
//export function indicarNombre(nombre: string): string {
   // return `Mi nombre es ${nombre}.`;
//}no era necesario 
// empiesa la historia 
//Sombras de Bortez
//Pantalla inicial: Oscuridad, sonidos metálicos, viento que sopla entre ruinas.
//Narrador Año 2147. La ciudad de Arcadia yace en ruinas tras el colapso tecnológico. Entre escombros y laboratorios
// olvidados, secretos prohibidos esperan ser descubiertos. Tú despiertas sin recuerdos, acompañado por Elena Bortez, 
// hija del hombre que creó esta pesadilla.

// el protagonista se despierta en arcadia, despierta sin recuerdo sin memoria, solo su nombre 
// elena lo encuentra y le cuenta el colaso, y notan que algo los viene siguiendo 
/*export function despertarEnArcadia(): string {
    return `Despiertas en las ruinas de Arcadia, sin recuerdos ni memoria, solo tu nombre resuena en tu mente. 
    Elena Bortez te encuentra entre los escombros y te cuenta sobre el colapso tecnológico que devastó la ciudad. Mientras 
    hablan, sienten una presencia inquietante que los sigue desde las sombras.`;
}
// siguen caminado hasta que encuentran tres caminos, cual desiden tomar 
export function encontrarCaminos(): string {
    return `Mientras caminan entre las ruinas, encuentran tres caminos distintos: uno hacia un laboratorio abandonado, 
    otro hacia una zona residencial destruida, y un tercero que se adentra en un bosque oscuro. ¿Cuál camino deciden tomar?`;
}
// eligen un camino
export function elegirCamino(camino: string): string {
    return `Deciden tomar el camino hacia el ${camino}, esperando encontrar respuestas sobre su pasado y el misterio que los sigue.`;
}
// camino 1 al laboratorio oscuro 
// esenario 1A: entran al laboratorio abandonado puertas oxidadas se habren y elena y el protagonista entran, pero elena duda al entrar
export function entrarLaboratorio(): string {
    return `Las puertas oxidadas del laboratorio se abren con un chirrido inquietante. Elena duda por un momento antes de entrar, 
    pero finalmente ambos deciden adentrarse en la oscuridad del lugar, buscando respuestas entre los restos de experimentos olvidados.`;
}
*/