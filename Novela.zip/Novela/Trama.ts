// integrantes
//  Arais Mendez 31442374
// Jesus Freitez 31277706
// Moises Contreras 30405571

import { styleText } from "util";
import { Final } from "./Final";
import { Personaje } from "./Personaje";
import { Ruta } from "./Ruta";
import { Decision } from "./Decision";
import { Escena } from "./Escena";
import { keyInSelect } from "readline-sync";

export class Trama{
    #personajes:Personaje[];
    #rutas:Ruta[];

    constructor(nombre:string){
        this.#personajes = [];
        this.#rutas = [];

        const PROTA = new Personaje(nombre,'bgCyan');
        const NARRADOR = new Personaje("Narrador",'bgGreen');
        const ELENA = new Personaje("Elena Bortez",'bgBlue');
        this.#personajes.push(PROTA,NARRADOR,ELENA);


        // RUTA DEL LABORATORIO
        const DLABORATORIO = new Decision(["Si, entremos de una vez.","Mejor revisemos el perimetro primero.","Retrocedamos, quiza haya otra entrada"],"Que decides hacer?");

        const ESC1A = new Escena([DLABORATORIO],this.#personajes,[
            "Narrador: Las puertas oxidadas se abren con un chirrido. El aire huele a polvo y quimicos.",
            "Elena Bortez: "+nombre+"... seguro que quieres entrar aqui? Algo me dice que no deberiamos."
        ]);

        const ESC2A = new Escena([],this.#personajes,[
            "Narrador: Montones de carpetas y pantallas apagadas. Un archivo lleva tu nombre.",
            "Elena Bortez: Por que habria algo tuyo aqui...?",
            nombre+": Revisare el archivo."
        ]);

        const ESC2B = new Escena([],this.#personajes,[
            "Narrador: Motores oxidados y luces parpadeantes. Parece seguro, pero inestable.",
            "Elena Bortez: Podemos salir por aqui.",
            nombre+": Seguir adelante."
        ]);

        const ESC2C = new Escena([],this.#personajes,[
            "Narrador: Un ruido fuerte detras de ti. Algo se acerca.",
            "Elena Bortez: "+nombre+", cuidado!",
            nombre+": Insistir en avanzar."
        ]);

        const FMISTLAB = new Final(new Escena([],this.#personajes,[
            "Narrador: Encuentras un archivo con tu nombre. Fuiste creado en este laboratorio.",
            "Elena Bortez: Entonces... tu tambien eres parte del experimento? Eso lo cambia todo.",
            nombre+": No soy quien pensaba... que significa mi existencia?",
            "Narrador: Quien controla realmente tu destino? Fijate en tu pantalla."
        ]),"Final Misterioso");

        const FNORMLAB = new Final(new Escena([],this.#personajes,[
            "Narrador: Escapan por la sala de maquinas hacia la salida. El amanecer ilumina un nuevo comienzo.",
            "Elena Bortez: Lo logramos, "+nombre+". Quizas aun haya esperanza.",
            nombre+": Si... pero el misterio del laboratorio seguira oculto.",
            "Narrador: Has sobrevivido, pero no conoces toda la verdad."
        ]),"Final Normal");

        const FGAMELAB = new Final(new Escena([],this.#personajes,[
            "Narrador: Una criatura surfe del pasillo bloqueado y te ataca sin piedad.",
            "Elena Bortez: Nooo,"+nombre+"!",
            "Narrador: Has caido en las sombras de Arcadia."
        ]),"Final Game Over");

        this.#rutas.push(new Ruta([ESC1A,ESC2A,ESC2B,ESC2C],this.#personajes,[FMISTLAB,FNORMLAB,FGAMELAB]));

        //RUTA DEL CALLEJON SIN SALIDA

        const DCALLEJON = new Decision([
            "Enfrentemos lo que sea.",
            "Corramos hacia la salida.",
            "Escondamonos en las sombras."
        ],"Algo viene!");

        const ESC1B =  new Escena([DCALLEJON],this.#personajes,[
            "Narrador: El callejon esta humedo y silencioso. Un ruido metalico resuena.",
            "Elena Bortez: Algo viene hacia nosotros!"
        ]);

        const ESC2D = new Escena([],this.#personajes,[
            "Narrador: Una bestia surge y te ataca sin piedad.",
            "Elena Bortez: Nooo,"+nombre+"!",
        ]);

        const ESC2E = new Escena([],this.#personajes,[
            "Narrador: Logras salir del callejon y ver la luz del amanecer.",
            "Elena Bortez: Lo conseguimos!",
            nombre+": Finalmente... Somos libres."
        ]);

        const ESC2F = new Escena([],this.#personajes,[
            "Narrador: Encuentras un tunel oculto que lleva al laboratorio.",
            "Elena Bortez: Que es este lugar...?"
        ]);

        const FMISTCAL = new Final(new Escena([],this.#personajes,[
            "Narrador: Encuentras un tunel oculto que lleva al laboratorio, dentro documentos revelan tu origen.",
            "Elena Bortez: Entonces todo esto estaba planeado... incluso tu?",
            nombre+": Soy parte de algo mas grande... y desconocido.",
            "Narrador: La verdad te consume. Quien eres realmente?"
        ]),"Final Misterioso");
        
        const FNORMCAL = new Final(new Escena([],this.#personajes,[
            "Narrador: Logras salir del callejon y ver la luz del amanecer.",
            "Elena Bortez: Estamos a salvo... por ahora.",
            nombre+": Si, pero Arcadia aun guarda secretos.",
            "Narrador: Has sobrevivido, pero el misterio continua."
        ]),"Final Normal");

        const FGAMECAL = new Final(new Escena([],this.#personajes,[
            "Narrador: Una bestia surge y ataca sin piedad.",
            "Elena Bortez: "+nombre+", nooooo!",
            "Narrador: Fin del juego, el callejon se convierte en tu tumba."
        ]),"Final Game Over");

        this.#rutas.push(new Ruta([ESC1B, ESC2D, ESC2E,ESC2F],this.#personajes,[FMISTCAL,FNORMCAL,FGAMECAL]));

        // RUTA DE LA SALA SELLADA

        const DSALA = new Decision([
            "Abramos la puerta",
            "Ignoremosla y sigamos",
            "Intentemos descifrar los simbolos"
        ],"Que hacer con la puerta?");

        const ESC1C = new Escena([DSALA],this.#personajes,[
            "Narrador: Una puerta metalica cubierta de simbolos extranios bloquea el paso.",
            "Elena Bortez: Que hacemos, "+nombre+"?"
        ]);

        const ESC2G = new Escena([],this.#personajes,[
            "Narrador: Dentro encuentras documentos con tu nombre",
            "Elena Bortez: Entonces... tu tambien eres parte del experimento?"
        ]);

        const ESC2H = new Escena([],this.#personajes,[
            "Narrador: Encuentras un tunel que lleva afuera de Arcadia.",
            "Elena Bortez: Estamos a salvo."
        ]);

        const ESC2I = new Escena([],this.#personajes,[
            "Narrador: Los simbolos brillan y liberan un mecanismo mortal.",
            "Elena Bortez: "+nombre+", nooooooooooo!"
        ]);

        const FMISTSAL = new Final(new Escena([],this.#personajes,[
            nombre+": No soy quien pensaba... Que significa mi existencia?",
            "Narrador: El misterio apenas comienza."
        ]),"Final Misterioso.");

        const FNORMSAL = new Final(new Escena([],this.#personajes,[
            nombre+": Si... pero nunca sabremos que habia tras esa puerta.",
            "Narrador: Has sobrevivido pero la verdad quedo sellada."
        ]),"Final Normal");

        const FGAMESAL = new Final(new Escena([],this.#personajes,[
            "Narrador: Has sido victima de la trampa. Fin."
        ]),"Final Game Over");

        this.#rutas.push(new Ruta([ESC1C,ESC2G,ESC2H,ESC2I],this.#personajes,[FMISTSAL,FNORMSAL,FGAMESAL]));
    }

    public arrancar(){
        let bandera = true;

        while(bandera){
            console.clear();
            console.log("====================");
            console.log("     SOMBRAS DE BORTEZ     ");
            console.log("====================");

            const prota = this.#personajes[0];

            const DINTRO = new Decision([
                "El laboratorio principal donde quizas encontremos respuestas.",
                "El callejon oscuro, que podria llevarnos a una salida rapida.",
                "O esa sala sellada, cubierta de simbolos extranios."
            ],"Que ruta eliges?");

            const intro = new Escena([],this.#personajes,[
                "Narrador: Anio 2147. La ciudad de Arcadia yace en ruinas tras el colapso tecnologico. Entre escombros y laboratorios olvidados, secretos prohibidos esperan ser descubiertos. Tu despiertas sin recuerdos, acompaniado por Elena Bortez, hija del hombre que creo esta pesadilla.",
                "Elena Bortez: "+prota.nombre+", estas bien? Te encontre inconsciente enter los restos de la ciudad. No se como sobreviviste.",
                prota.nombre+": No recuerdo nada... solo mi nombre. Que paso aqui?",
                "Elena Bortez: Arcadia fue destruida por los experimentos de mi padre. Y ahora... algo nos persigue.",
                "Narrador: El viento arrastra ecos de pasos metalicos. La ciudad parece observarlos.",
                "Elena Bortez: Debemos movernos, hay tres caminos.",
            ]);
            intro.iniciar();

            let respuesta = prota.tomarDecision(DINTRO);

            if(this.#rutas[respuesta]){
                this.#rutas[respuesta].iniciar();
            }

            console.log("\n")
            let opcionesReinicio = ["Leer la novela de nuevo","Salir del programa"];
            let seleccionReinicio = keyInSelect(opcionesReinicio,"Quiere ver la historia de nuevo?",{cancel:false});

            if(seleccionReinicio == 1){
                bandera = false;
                console.log("Gracias por ejecutar la historia.");
            }
        }
    }
}